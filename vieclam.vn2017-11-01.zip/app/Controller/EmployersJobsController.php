<?php
class EmployersJobsController extends AppController
{
//    public $name = 'EmployerJob';
}