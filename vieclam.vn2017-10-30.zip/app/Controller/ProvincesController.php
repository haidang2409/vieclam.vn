<?php
class ProvincesController extends AppController
{
    //All
    function _get_province_option()
    {
        $provinces = null;
        $this->Province->recursive = -1;
        $province = $this->Province->find('all');
        if($province)
        {
            foreach ($province as $item)
            {
                $provinces[$item['Province']['id']] = $item['Province']['provincename'];
            }
        }
        return $provinces;
    }
    function _get_province_option_link()
    {
        $provinces = null;
        $this->Province->recursive = -1;
        $province = $this->Province->find('all');
        if($province)
        {
            foreach ($province as $item)
            {
                $provinces[$item['Province']['provincelink'] . '-p' . $item['Province']['id']] = $item['Province']['provincename'];
            }
        }
        return $provinces;
    }


}