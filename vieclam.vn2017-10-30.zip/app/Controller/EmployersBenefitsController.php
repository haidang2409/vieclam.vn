<?php
class EmployersBenefitsController extends AppController
{
    public $name = 'EmployerBenefit';
    function index()
    {

    }
}