<?php
class MembersRecruitmentsController extends AppController
{
    public $name = 'MemberRecruitment';
    public $components = array('Mailtemplate', 'Library');

    //User
    ////////////////////////////////

    //Employer
    ////////////////////////////////
    function update_status()
    {
        $this->autoRender = false;
        if($this->Session->check('S_Employer'))
        {
            $employer_id = $this->Session->read('S_Employer.id');
            $memberRecruitmentId = $this->request->data['memberRecruitmentId'];
            $recruitmentStatusId = $this->request->data['recruitmentStatusId'];
            $this->MemberRecruitment->recursive = -1;
            $member_recruitments = $this->MemberRecruitment->find('first', array(
                'joins' => array(
                    array(
                        'table' => 'recruitments',
                        'alias' => 'Recruitment',
                        'type' => 'INNER',
                        'foreignKey' => false,
                        'conditions' => 'MemberRecruitment.recruitment_id = Recruitment.id'
                    ),
                ),
                'conditions' => array(
                    'MemberRecruitment.id' => $memberRecruitmentId,
                    'Recruitment.employer_id' => $employer_id
                )
            ));
            if($member_recruitments)
            {
                $this->MemberRecruitment->set('id', $memberRecruitmentId);
                $this->MemberRecruitment->set('recruitment_status_id', $recruitmentStatusId);
                if($this->MemberRecruitment->save())
                {
                    echo json_encode(array('status' => 'success'));
                }
                else
                {
                    echo json_encode(array('status' => 'fail'));
                }

            }
            else
            {
                echo json_encode(array('status' => 'fail'));
            }
        }
        else
        {
            echo json_encode(array('status' => 'not_login'));
        }
    }

}