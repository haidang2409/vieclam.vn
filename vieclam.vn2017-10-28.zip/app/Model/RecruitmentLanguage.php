<?php
class RecruitmentLanguage extends AppModel
{
    public $useTable = 'recruitments_languages';
    public $hasMany = array(
        'Recruitment' => array(
            'className' => 'Recruitment',
            'foreignKey' => 'language_recruitment_id'
        )
    );
}