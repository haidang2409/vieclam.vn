<?php
class PostCategory extends AppModel
{
    public $useTable = 'posts_categories';
    public $hasMany = array(
        'Post' => array(
            'className' => 'Post',
            'foreignKey' => 'post_category_id'
        )
    );

    //Validate
    public $validate = array(
        'name' => array(
            'notBlank' => array(
                'rule' => 'notBlank',
                'message' => 'Nhập chuyên mục bài viết'
            ),
            'between' => array(
                'rule' => array('between', 5, 100),
                'message' => 'Chuyên mục bài viết từ %d đến %d ký tự'
            )
        )
    );
}