<?php
class MembersRecruitmentsController extends AppController
{
    public $name = 'MemberRecruitment';
    public $components = array('Mailtemplate', 'Library');

    //User
    ////////////////////////////////
    function delete_saved_ajax()
    {
        $this->autoRender = false;
        if($this->Session->check('S_Member'))
        {
            if($this->request->is('post'))
            {
                $member_id = $this->Session->read('S_Member.id');
                $id = $this->request->data['id'];
                $this->MemberRecruitment->recursive = -1;
                $members_recruitments = $this->MemberRecruitment->find('first', array(
                    'conditions' => array(
                        'id' => $id,
                        'member_id' => $member_id
                    )
                ));
                if($members_recruitments)
                {
                    if($members_recruitments['MemberRecruitment']['is_applied'] == 1)
                    {
                        echo json_encode(array('status' => 'applied', 'message' => 'Tin đã ứng tuyển'));
                    }
                    else
                    {
                        $this->MemberRecruitment->delete($id);
                        echo json_encode(array('status' => 'success', 'message' => 'Đã xóa'));
                    }
                }
                else
                {
                    echo json_encode(array('status' => 'fail', 'message' => 'Lỗi'));
                }
            }
        }
        else
        {
            echo json_encode(array('status' => 'not_login', 'message' => 'Vui lòng đăng nhập'));
        }
    }
    //Employer
    ////////////////////////////////
    function update_status()
    {
        $this->autoRender = false;
        if($this->Session->check('S_Employer'))
        {
            $employer_id = $this->Session->read('S_Employer.id');
            $memberRecruitmentId = $this->request->data['memberRecruitmentId'];
            $recruitmentStatusId = $this->request->data['recruitmentStatusId'];
            $this->MemberRecruitment->recursive = -1;
            $member_recruitments = $this->MemberRecruitment->find('first', array(
                'joins' => array(
                    array(
                        'table' => 'recruitments',
                        'alias' => 'Recruitment',
                        'type' => 'INNER',
                        'foreignKey' => false,
                        'conditions' => 'MemberRecruitment.recruitment_id = Recruitment.id'
                    ),
                ),
                'conditions' => array(
                    'MemberRecruitment.id' => $memberRecruitmentId,
                    'Recruitment.employer_id' => $employer_id
                )
            ));
            if($member_recruitments)
            {
                $this->MemberRecruitment->set('id', $memberRecruitmentId);
                $this->MemberRecruitment->set('recruitment_status_id', $recruitmentStatusId);
                if($this->MemberRecruitment->save())
                {
                    echo json_encode(array('status' => 'success'));
                }
                else
                {
                    echo json_encode(array('status' => 'fail'));
                }

            }
            else
            {
                echo json_encode(array('status' => 'fail'));
            }
        }
        else
        {
            echo json_encode(array('status' => 'not_login'));
        }
    }

}