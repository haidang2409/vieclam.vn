<?php
class JobsController extends AppController
{
    //Import

    //All
    function _get_jobs_option()
    {
        $jobs = null;
        $this->Job->recursive = -1;
        $job = $this->Job->find('all', array(
            'conditions' => array()
        ));
        if($job)
        {
            foreach ($job as $item)
            {
                $jobs[$item['Job']['id']] = $item['Job']['jobname'];
            }
        }
        return $jobs;
    }
    function _get_jobs_option_link()
    {
        $jobs = null;
        $this->Job->recursive = -1;
        $job = $this->Job->find('all', array(
            'conditions' => array()
        ));
        if($job)
        {
            foreach ($job as $item)
            {
                $jobs[$item['Job']['joblink'] . '-j' . $item['Job']['id']] = $item['Job']['jobname'];
            }
        }
        return $jobs;
    }
    ////////////////////////////
    //User



    ////////////////////////////
    //Employer



    ////////////////////////////
    //Admin




}