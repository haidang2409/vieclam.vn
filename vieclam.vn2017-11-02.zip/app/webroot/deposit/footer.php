<div class="footer text-center-xs">
    <div class="container" style="padding-top: 20px; padding-bottom: 20px;">
        <div class="row">
            <div class="col-sm-9" style="font-size: 14px">
                Bản quyền <span class="fa fa-copyright"></span> 2017, vui lòng ghi rõ nguồn <u>nhadatphong.com</u> khi phát hành lại thông tin từ website này!
                <br>
                CÔNG TY TNHH TƯ VẤN VÀ ĐÀO TẠO HIỆN THỰC ƯỚC MƠ
                <br>
                <i class="fa fa-phone"></i> 0901 032 320 - <i class="fa fa-envelope"></i> cskh@dream.edu.vn
                <br>
                <i class="fa fa-home"></i>
                Địa chỉ VP: Số 86 Mạc Thiên Tích, Phường Xuân Khánh, Quận Ninh Kiều, TP Cần Thơ
                <br>
                <span>
                    Hoạt động theo giấy phép đăng ký kinh doanh số - Cấp ngày // Sở kế hoạch và đầu tư TP Cần Thơ
                </span>
            </div>
            <div class="col-sm-3 text-center-xs text-right">
                <img src="/img/bocongthuong.png" width="200px" align="Đã đăng ký với bộ công thương">
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="/js/ace.min.js"></script>